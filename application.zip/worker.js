var n1 = 0;
var n2 = 1;
var nextTerm = 0;
var i = 0;

while (true) {
    nextTerm = n1 + n2;
    n1 = n2;
    n2 = nextTerm;
    if (i % 100 == 0) {
        //postMessage('Counter ' + i + ' result ' + n1);
    }
    i += 1;
}

